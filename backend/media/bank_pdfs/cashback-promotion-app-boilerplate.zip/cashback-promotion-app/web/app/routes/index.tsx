import { useEffect, useState } from "react";
import axios from "axios";

export default function Index() {
  const [rules, setRules] = useState([]);
  const [threshold, setThreshold] = useState('');
  const [percentage, setPercentage] = useState('');

  useEffect(() => {
    axios.get("http://localhost:8000/api/rules/")
      .then(res => setRules(res.data));
  }, []);

  const handleSubmit = async () => {
    await axios.post("http://localhost:8000/api/rules/", {
      threshold,
      percentage
    });
    window.location.reload();
  };

  return (
    <div>
      <h1>Cashback Rules</h1>
      <input placeholder="Order Threshold" value={threshold} onChange={e => setThreshold(e.target.value)} />
      <input placeholder="Percentage" value={percentage} onChange={e => setPercentage(e.target.value)} />
      <button onClick={handleSubmit}>Create Rule</button>
      <ul>
        {rules.map(rule => (
          <li key={rule.id}>{rule.threshold} - {rule.percentage}%</li>
        ))}
      </ul>
    </div>
  );
}
