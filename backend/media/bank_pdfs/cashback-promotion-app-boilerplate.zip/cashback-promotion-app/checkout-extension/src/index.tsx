import {
  useExtensionApi,
  Banner,
} from '@shopify/checkout-ui-extensions-react';

export default function Extension() {
  const { checkout } = useExtensionApi();

  const amount = parseFloat(checkout.totalAmount.amount);
  const cashback = amount > 100 ? (amount * 0.10).toFixed(2) : null;

  return cashback ? (
    <Banner title={`Congrats! You'll get $${cashback} in store credit after purchase.`} status="success" />
  ) : null;
}
