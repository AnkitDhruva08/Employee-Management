from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CashbackRuleViewSet, CashbackTransactionViewSet

router = DefaultRouter()
router.register(r'rules', CashbackRuleViewSet)
router.register(r'transactions', CashbackTransactionViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
