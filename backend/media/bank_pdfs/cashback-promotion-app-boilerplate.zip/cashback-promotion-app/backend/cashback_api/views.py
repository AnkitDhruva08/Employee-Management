from rest_framework import viewsets
from .models import CashbackRule, CashbackTransaction
from .serializers import CashbackRuleSerializer, CashbackTransactionSerializer

class CashbackRuleViewSet(viewsets.ModelViewSet):
    queryset = CashbackRule.objects.all()
    serializer_class = CashbackRuleSerializer

class CashbackTransactionViewSet(viewsets.ModelViewSet):
    queryset = CashbackTransaction.objects.all()
    serializer_class = CashbackTransactionSerializer
