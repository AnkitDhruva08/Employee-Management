from rest_framework import serializers
from .models import CashbackRule, CashbackTransaction

class CashbackRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashbackRule
        fields = '__all__'

class CashbackTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashbackTransaction
        fields = '__all__'
