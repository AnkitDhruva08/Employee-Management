# Shopify Cashback Promotion App

This app allows Shopify merchants to offer cashback during checkout.

## Features

- ✅ Checkout UI Extension (Shopify checkout banner)
- ✅ Admin Dashboard with Remix + React
- ✅ Django REST API backend
- ✅ Cashback rules and transaction tracking

## Tech Stack

- Remix (Frontend)
- Django REST (Backend)
- Shopify UI Extensions

## Setup Instructions

1. Clone the repo and run Django backend:
   ```
   cd backend
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py runserver
   ```

2. Start the Remix admin:
   ```
   cd web
   npm install
   npm run dev
   ```

3. Run Checkout UI Extension using Shopify CLI:
   ```
   shopify extension serve
   ```
